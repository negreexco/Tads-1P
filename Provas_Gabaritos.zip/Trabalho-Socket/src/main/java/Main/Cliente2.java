package Main;

import java.io.*;
import java.net.Socket;

/**
 * Classe Cliente2
 * Simula outro cliente conectando ao servidor e enviando um arquivo diferente.
 */
public class Cliente2 extends Thread {

    public static void main(String[] args) {
        try {
            // Conecta ao servidor na mesma porta do Cliente
            Socket conexao = new Socket("localhost", 12345);
            System.out.println("Conectado ao servidor na porta 12345.");

            // Inicia uma nova thread para gerenciar a comunicação
            Thread t = new Cliente2(conexao);
            t.start();

        } catch (IOException e) {
            System.err.println("Erro ao conectar ao servidor: " + e.getMessage());        }
    }

    private Socket conexao;

    public Cliente2(Socket s) {
        this.conexao = s;
    }

    @Override
    public void run() {
        try {
            System.out.println("O cliente 2 se conectou ao servidor!");

            // Cria uma conexão usando a classe Conexao
            Conexao conexaoCliente = new Conexao(conexao);

            // Instância do manipulador para lidar com o arquivo de respostas
            Manipulador manipulador = new Manipulador();

            // Caminho fixo do arquivo de respostas para o Cliente2
            String caminho = "C:/Users/leoso/OneDrive/Anexos/Trabalho-Socket/src/main/java/Main/ProvaCliente2.txt";

            // Lê o conteúdo e o número de linhas do arquivo
            String conteudo = manipulador.LerConteudo(caminho);
            int quantidadeLinhas = manipulador.ContarLinhas(caminho);

            // Envia os dados para o servidor
            conexaoCliente.enviarMensagem(conteudo);
            conexaoCliente.enviarInteiro(quantidadeLinhas);

            System.out.println("Cliente 2 enviou as respostas com sucesso!");

            // Fecha a conexão após o envio
            conexaoCliente.close();

        } catch (IOException e) {
            System.err.println("Erro no Cliente2: " + e.getMessage());
        } finally {
            try {
                conexao.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

