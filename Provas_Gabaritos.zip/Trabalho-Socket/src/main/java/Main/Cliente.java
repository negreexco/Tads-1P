package Main;

import java.io.IOException;
import java.net.Socket;

/**
 * Classe Cliente
 * Responsável por enviar o arquivo com as respostas ao servidor.
 * Esta classe utiliza a classe {@link Conexao} para gerenciar a comunicação com o servidor.
 * 
 * @author leoso
 */
public class Cliente extends Thread {
    
    private Socket conexao;

    /**
     * Construtor da classe Cliente.
     * 
     * @param conexao O socket que conecta o cliente ao servidor.
     */
    public Cliente(Socket conexao) {
        this.conexao = conexao;
    }

    /**
     * Método principal do cliente.
     * Estabelece a conexão com o servidor e inicia uma thread para comunicação.
     * 
     * @param args Argumentos de linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        try {
            // Conecta ao servidor na porta 12349
            Socket conexao = new Socket("localhost", 12345);
            System.out.println("Conectado ao servidor na porta 12345.");

            // Inicia uma nova thread para gerenciar a comunicação
            Thread t = new Cliente(conexao);
            t.start();

        } catch (IOException e) {
            System.err.println("Erro ao conectar ao servidor: " + e.getMessage());
        }
    }

    /**
     * Método que executa a lógica do cliente para envio de dados ao servidor.
     * Este método é executado em uma nova thread.
     */
    @Override
    public void run() {
        try (Conexao conexaoCliente = new Conexao(conexao)) {
            System.out.println("Cliente conectado ao servidor!");

            // Caminho fixo do arquivo de respostas
            String caminho = "C:/Users/leoso/OneDrive/Anexos/Trabalho-Socket/src/main/java/Main/Prova.txt";

            // Lê o conteúdo e o número de linhas do arquivo
            Manipulador manipulador = new Manipulador();
            String conteudo = manipulador.LerConteudo(caminho);
            int quantidadeLinhas = manipulador.ContarLinhas(caminho);

            // Envia os dados para o servidor
            conexaoCliente.enviarMensagem(conteudo);
            conexaoCliente.enviarInteiro(quantidadeLinhas);

            System.out.println("Dados enviados ao servidor com sucesso!");

        } catch (IOException e) {
            System.err.println("Erro ao enviar dados ao servidor: " + e.getMessage());
        }
    }
}
