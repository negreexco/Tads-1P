package Main;

import java.io.*;
import java.net.Socket;

/**
 * Classe responsável por encapsular a comunicação via socket entre cliente e servidor.
 * 
 * Esta classe fornece métodos para enviar e receber mensagens e inteiros através de um socket.
 * O construtor exige que um socket já inicializado seja passado como parâmetro, e cria streams de entrada e saída
 * para comunicação.
 */
public class Conexao implements AutoCloseable {
    private final Socket socket;
    private final DataInputStream entrada;
    private final DataOutputStream saida;

    /**
     * Constrói uma instância de Conexao usando um socket existente.
     * 
     * @param socket Um socket já conectado que será usado para comunicação.
     * @throws IOException Se ocorrer um erro ao inicializar as streams de entrada e saída.
     */
    public Conexao(Socket socket) throws IOException {
        this.socket = socket;
        this.entrada = new DataInputStream(socket.getInputStream());
        this.saida = new DataOutputStream(socket.getOutputStream());
    }

    /**
     * Envia uma mensagem ao destino através do socket.
     * 
     * @param mensagem A mensagem a ser enviada, no formato de string UTF-8.
     *                 Não pode ser nula.
     * @throws IOException Se ocorrer um erro de E/S ao enviar a mensagem.
     */
    public void enviarMensagem(String mensagem) throws IOException {
        saida.writeUTF(mensagem);
    }

    /**
     * Recebe uma mensagem do socket.
     * 
     * @return A mensagem recebida, no formato de string UTF-8.
     * @throws IOException Se ocorrer um erro de E/S ao receber a mensagem.
     */
    public String receberMensagem() throws IOException {
        return entrada.readUTF();
    }

    /**
     * Envia um valor inteiro ao destino através do socket.
     * 
     * @param valor O valor inteiro a ser enviado.
     * @throws IOException Se ocorrer um erro de E/S ao enviar o valor.
     */
    public void enviarInteiro(int valor) throws IOException {
        saida.writeInt(valor);
    }

    /**
     * Recebe um valor inteiro do socket.
     * 
     * @return O valor inteiro recebido.
     * @throws IOException Se ocorrer um erro de E/S ao receber o valor.
     */
    public int receberInteiro() throws IOException {
        return entrada.readInt();
    }

    /**
     * Fecha todos os recursos associados à conexão, incluindo o socket, as streams de entrada e saída.
     * Caso ocorra uma exceção ao fechar qualquer recurso, ela será registrada no log.
     */
    @Override
    public void close() {
        try {
            if (entrada != null) entrada.close();
            if (saida != null) saida.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            logErro("Erro ao fechar conexão", e);
        }
    }

    /**
     * Registra uma mensagem de erro no console.
     * 
     * @param mensagem Mensagem descritiva do erro.
     * @param e Exceção lançada.
     */
    private void logErro(String mensagem, Exception e) {
        System.err.println(mensagem);
        e.printStackTrace();
    }
}
