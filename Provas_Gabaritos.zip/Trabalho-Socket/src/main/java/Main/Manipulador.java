package Main;

import java.io.*;

/**
 * Classe utilitária para manipulação de arquivos e processamento de respostas e gabaritos.
 */
public class Manipulador {
    /**
     * Lê o conteúdo de um arquivo texto e retorna como uma string.
     * 
     * @param caminho O caminho completo para o arquivo.
     * @return O conteúdo do arquivo como string.
     * @throws java.io.IOException
     */
    public String LerConteudo(String caminho) throws IOException {
        StringBuilder conteudo = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                conteudo.append(linha).append("\n");
            }
        }
        return conteudo.toString();
    }

    /**
     * Conta o número de linhas de um arquivo texto.
     * 
     * @param caminho O caminho completo para o arquivo.
     * @return O número de linhas no arquivo.
     * @throws java.io.IOException
     */
    public int ContarLinhas(String caminho) throws IOException {
        try (LineNumberReader linhaReader = new LineNumberReader(new FileReader(caminho))) {
            linhaReader.skip(Long.MAX_VALUE);
            return linhaReader.getLineNumber() + 1;
        }
    }

  /**
 * Processa o conteúdo de respostas em um formato bidimensional, considerando o formato "1-xxxxx" ou "10-xxxxx".
 *
     * @param caminhoArquivo
     * @param quatidadeLinha
     *@return Um vetor bidimensional com as respostas processadas.
     * @throws java.io.IOException
 */
public String[][] LerRespostas(String caminhoArquivo, int quatidadeLinha) throws IOException {

        String Stringrespostas = caminhoArquivo;

        String respostas[][] = new String[1][quatidadeLinha + 1];
        int contagem = 3;

        for (int i = 0; i <= respostas[0].length - 1; i++) {
            respostas[0][i] = String.valueOf(Stringrespostas.trim().subSequence(contagem, contagem + 4));

            contagem += 8;
        }
        return respostas;
    }

    /**
     * Compara as respostas com o gabarito e imprime os resultados.
     * 
     * @param respostas As respostas do aluno.
     * @param gabarito As respostas corretas.
     */
public void CompararRespostas(String[][] respostas, String[][] gabarito, String identificador) {
    int totalAcertos = 0;
    int totalErros = 0;

    System.out.println("\nResultados: " + identificador);
    for (int i = 0; i < respostas[0].length; i++) {
        System.out.println("Questão " + (i + 1));
        if (respostas[0][i].equals(gabarito[0][i])) {
            System.out.println("Acertou!");
            totalAcertos++;
        } else {
            System.out.println("Errou!");
            totalErros++;
        }
    }

    System.out.println("\nResumo: " + identificador);
    System.out.println("Total de acertos: " + totalAcertos);
    System.out.println("Total de erros: " + totalErros);
    System.out.println("----------------------------------");
}

}
