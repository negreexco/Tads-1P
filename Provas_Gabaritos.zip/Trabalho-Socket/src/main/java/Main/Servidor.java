package Main;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


/**
 * Classe Servidor que implementa um servidor de rede baseado em sockets.
 * Essa classe aceita conexões de clientes, recebe dados e processa informações relacionadas.
 * 
 * Ele utiliza a classe {@link Conexao} para gerenciar a comunicação de maneira mais eficiente.
 * 
 * @author leoso
 */
public class Servidor extends Thread {

    private Socket conexao;

    /**
     * Construtor da classe Servidor que recebe um socket de conexão.
     * 
     * @param conexao O socket associado a um cliente conectado.
     */
    public Servidor(Socket conexao) {
        this.conexao = conexao;
    }

    /**
     * Método principal do servidor, responsável por iniciar e escutar conexões de clientes.
     * 
     * @param args Argumentos de linha de comando (não utilizados).
     */
public static void main(String[] args) {
    try (ServerSocket serverSocket = new ServerSocket(12345)) {
        System.out.println("Servidor iniciado e aguardando conexões...");
        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("Conexão recebida de: " + socket.getInetAddress().getHostAddress());
            new Servidor(socket).start(); // Inicia uma nova thread para o cliente
        }
    } catch (IOException e) {
        System.err.println("Erro no servidor: " + e.getMessage());
    }
}


    /**
     * Método que executa a lógica para processar os dados do cliente.
     * Este método é executado em uma nova thread para cada cliente conectado.
     */
    @Override
    public void run() {
        try (Conexao conexaoCliente = new Conexao(conexao)) {
            System.out.println("Processando dados do cliente " + conexao.getInetAddress().getHostAddress());

            // Lê os dados enviados pelo cliente
            String caminhoArquivo = conexaoCliente.receberMensagem();
            int qtdLinhas = conexaoCliente.receberInteiro();

            // Processa o arquivo recebido
            Manipulador manipulador = new Manipulador();
            String[][] respostas = manipulador.LerRespostas(caminhoArquivo, qtdLinhas);

            // Lê o gabarito no servidor
            String gabarito = manipulador.LerConteudo("C:/Users/leoso/OneDrive/Anexos/Trabalho-Socket/src/main/java/Main/gabarito.txt");
            int gabaLinhas = manipulador.ContarLinhas("C:/Users/leoso/OneDrive/Anexos/Trabalho-Socket/src/main/java/Main/gabarito.txt");

            // Processa o gabarito e verifica respostas
            String[][] gabaritoVetor = manipulador.LerRespostas(gabarito, gabaLinhas);
            manipulador.CompararRespostas(respostas, gabaritoVetor, "Cliente");


            System.out.println("Processamento finalizado para o cliente " + conexao.getInetAddress().getHostAddress());
        } catch (IOException e) {
            System.err.println("Erro ao processar os dados do cliente: " + e.getMessage());
        }
    }
    
}
