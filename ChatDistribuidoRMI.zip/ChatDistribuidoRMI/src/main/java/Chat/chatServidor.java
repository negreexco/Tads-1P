package Chat;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class chatServidor extends UnicastRemoteObject implements ChatInterface {

    private ArrayList<String> texto;
    private int usuariosAtivos = 0;

    public chatServidor() throws RemoteException {
        super();
        this.texto = new ArrayList<>();
    }

    // Método para armazenar mensagens
    public void enviarMensagem(String msg) throws RemoteException {
        texto.add(msg);
    }

    // Método para ler mensagens
    public ArrayList<String> lerMensagem() throws RemoteException {
        return texto;
    }

    // Método para obter a contagem de usuários ativos
    public int getUsuariosAtivos() throws RemoteException {
        return usuariosAtivos;
    }

    // Método para adicionar um usuário ativo
    public synchronized void conectarUsuario() throws RemoteException {
        usuariosAtivos++;
        System.out.println("Novo usuário conectado. Total: " + usuariosAtivos);
    }

    // Método para remover um usuário ativo
    public synchronized void desconectarUsuario() throws RemoteException {
        if (usuariosAtivos > 0) {
            usuariosAtivos--;
        }
        System.out.println("Usuário desconectado. Total: " + usuariosAtivos);
    }
}
