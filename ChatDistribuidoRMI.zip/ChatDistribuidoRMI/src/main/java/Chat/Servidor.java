package Chat;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.swing.JOptionPane;

/* @author Leandro e Letícia */

public class Servidor {
    public Servidor(){
        try {
            // Criando o servidor.
            // Registro do objeto remoto com RMI Registry.
            Registry registry = LocateRegistry.createRegistry(1099);
            ChatInterface server = new chatServidor();
            Naming.rebind("rmi://localhost:1099/ServidorChat", server);

            JOptionPane.showMessageDialog(null, "Servidor RMI iniciado.");

        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void main (String args[]){
        new Servidor();
    }

}