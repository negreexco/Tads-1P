package Chat;

import java.rmi.*;

public class Cliente {

    public static void main(String args[]) {
        JFrameCliente clienteInterface = new JFrameCliente();
        try {
            // Stub para o objeto remoto Chat do registro.
            ChatInterface chat = (ChatInterface) Naming.lookup("rmi://localhost:1099/ServidorChat");

            String nome = "";
            String msg;

            // Conectando o usuário ao servidor
            chat.conectarUsuario();
            clienteInterface.setUsuariosAtivos(chat.getUsuariosAtivos()); // Atualiza a interface

            // Espera o usuário inserir um nome e pressionar o botão OK.
            while (!clienteInterface.getFlag()) {
                nome = clienteInterface.getNome();
            }

            // Criando a Thread para receber mensagens
            Thread thread = new Thread(new Runnable() {
                int cont = 0;

                @Override
                public void run() {
                    try {
                        while (true) {
                            if (chat.lerMensagem().size() > cont) {
                                clienteInterface.setChat(chat.lerMensagem().get(chat.lerMensagem().size() - 1));
                                cont++;
                            }

                            // Atualiza a contagem de usuários na interface a cada 5s
                            clienteInterface.setUsuariosAtivos(chat.getUsuariosAtivos());
                            Thread.sleep(5000);
                        }
                    } catch (RemoteException | InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

            while (clienteInterface.sair()) {
                Thread.sleep(1000);
                if (clienteInterface.getBntWasPressed()) {
                    msg = " [" + nome + "]: " + clienteInterface.getTexto() + "\n";
                    if (!clienteInterface.getTexto().equals("")) {
                        chat.enviarMensagem(msg);
                        clienteInterface.setTexto("");
                    }
                }
                clienteInterface.setBtnWasPressedFalse();
            }

            // Usuário saiu, desconectar do servidor
            chat.desconectarUsuario();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
