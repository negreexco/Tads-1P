package Chat;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface ChatInterface extends Remote {
    void enviarMensagem(String msg) throws RemoteException;
    ArrayList<String> lerMensagem() throws RemoteException;

    // Novos métodos para contar usuários ativos
    int getUsuariosAtivos() throws RemoteException;
    void conectarUsuario() throws RemoteException;
    void desconectarUsuario() throws RemoteException;
}
