
package controller;
import daoccs.DaoFunc;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Funcionario;
/**
 *
 * @author leoso
 */
public class ControllerFunc {
    DaoFunc dao = new DaoFunc();
    List<Funcionario> lista= new ArrayList<Funcionario>();
    
      public void Contratar(Funcionario f)
    {
        if(!f.nome.equals("")&& f.cod_dep!=0 &&!f.Cargo.equals("") && !f.cpf.equals("") )
        {
            dao.Contratar(f);
            JOptionPane.showMessageDialog(null,"Funcionário contratado");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
    
     public void alter(Funcionario f)
    {
        if(!f.nome.equals("")&& f.cod_dep!=0 &&!f.Cargo.equals("") && !f.cpf.equals("")&& f.codigo!=0 )
        {
            dao.Remanejar(f);
            JOptionPane.showMessageDialog(null,"Alterações salvas com sucesso!!!");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }}
     
     public void Fire(int codigo)
    {
        int op = JOptionPane.showConfirmDialog(null, "Você tem certeza que quer desligar o funcionário de codigo "+codigo+" da empresa?","Certeza?",JOptionPane.YES_NO_OPTION);
       switch(op)
       {
           case 0 -> {
               dao.Demitir(codigo);
               JOptionPane.showMessageDialog(null, "Dispensado com sucesso!!!");
            }
           case 1 -> JOptionPane.showMessageDialog(null, "Exclusão cancelada");
       }
       
    }
     
        
  public List<Funcionario> updatedep(){
    
        lista.clear();
        lista = dao.getFuncionario();
        return lista;
    }
    
}

