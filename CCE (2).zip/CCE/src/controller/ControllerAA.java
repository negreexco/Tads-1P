/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import daoccs.daoAA;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Area_atuacao;

/**
 *
 * @author Afranio
 */
public class ControllerAA {
    daoAA dao = new daoAA();
    List<Area_atuacao> list=  new ArrayList<Area_atuacao>();
     List<String> areas = new ArrayList<String>();
    public void insertAA(Area_atuacao aa)
    {
        if(!aa.area.equals(""))
        {
            dao.saveaar(aa);
            JOptionPane.showMessageDialog(null,"Area de atuação salva com sucesso!");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
    
     public void alterAA(Area_atuacao aa)
    {
       if (aa.area != null && !aa.area.isEmpty()) {
        // O código dentro deste bloco será executado apenas se aa.area não for nulo e não estiver vazio.
        dao.alteraa(aa);
        JOptionPane.showMessageDialog(null, "Area de atuação alterada com sucesso!!!");
    } else {
        JOptionPane.showMessageDialog(null, "O campo de área deve ser preenchido");
    }

    }
     
     public void trashaa(String aid)
    {
        int op = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir a area de atuação selecionada?"+aid,"Certeza?",JOptionPane.YES_NO_OPTION);
       switch(op)
       {
           case 0:
               dao.killaa(aid);
               JOptionPane.showMessageDialog(null, "Excluído com sucesso!!!");
                            
               break;
           case 1:
               JOptionPane.showMessageDialog(null, "Exclusão cancelada");
               break;
       }
    } 
    public List<Area_atuacao> upuparea()
    {
        list.clear();
        list = dao.getaa();
        return list;
    }
    public List<String> cmbopen()
    {
        areas.clear();
        areas = dao.carregaComboBox();
        return areas;
    }
    public int idbyarea(String area)
    {
          return dao.idbyarea(area);
    }
    public String areabyid(String aid)
    {
         return dao.areabyid(aid);
    }
}
