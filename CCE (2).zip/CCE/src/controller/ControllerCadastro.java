
package controller;

import daoccs.DaoCadastro;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Cadastro;

/**
 *
 * @author Afranio
 */
public class ControllerCadastro {
    DaoCadastro dao = new DaoCadastro();
    List<Cadastro> lista= new ArrayList<Cadastro>();
    public void inserirCadastro(Cadastro c)
    {
        if(!c.CNPJ.equals("")&& c.IE!=0 &&c.area_atuacao!=0 && !c.nome.equals(""))
        {
            dao.inserirCadastro(c);
            JOptionPane.showMessageDialog(null,"Cadastro realizado com sucesso");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
    
     public void modCadastro(Cadastro c)
    {
        if(!c.CNPJ.equals("") && c.IE!=0 && c.area_atuacao!=0 && !c.fantasia.equals("")&& !c.nome.equals(""))
        {
            dao.modificarCadastro(c);
            JOptionPane.showMessageDialog(null,"Alterações salvas com sucesso!!!");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
     
     public void trashCce(int codigo)
    {
        int op = JOptionPane.showConfirmDialog(null, "Você tem certeza que quer excluir o cadastro?"+codigo,"Certeza?",JOptionPane.YES_NO_OPTION);
       switch(op)
       {
           case 0 -> {
               dao.apagarCadastro(codigo);
               JOptionPane.showMessageDialog(null, "Cadastro eliminado com sucesso!!!");
            }
           case 1 -> JOptionPane.showMessageDialog(null, "Eliminação cancelada");
       }
    } 
     public void procurar (Cadastro c){
     if(!c.nome.equals(""))
        {
            dao.procurar(c);
            JOptionPane.showMessageDialog(null,"Busca realizada com sucesso");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Dados preenchidos não constam");
        }
     }
    public List<Cadastro> upupCadastro()
    {
        lista.clear();
        lista = dao.getCadastro();
        return lista;
    }
}
