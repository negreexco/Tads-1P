
package controller;
import daoccs.DaoCcsUser;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Usuario;
/**
 *
 * @author leoso
 */
public class ControllerUser {
     DaoCcsUser dao = new DaoCcsUser();
    List<Usuario> lista= new ArrayList<Usuario>();
    
     public void inserirCadastro(Usuario u)
    {
        if(!u.Usuario.equals("") && !u.senha.equals(""))
        {
            dao.inserirCadastro(u);
            JOptionPane.showMessageDialog(null,"Usuario cadastrado com sucesso");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
     public List<Usuario> upupUser()
    {
        lista.clear();
        lista = dao.getUsuarios();
        return lista;
    }
}
