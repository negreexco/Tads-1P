/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import daoccs.DaoDep;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Departamento;

/**
 *
 * @author leoso
 */
public class ControllerDep {
    DaoDep dao = new DaoDep();
    List<Departamento> lista= new ArrayList<Departamento>();
    
    public void inserirDepartamento(Departamento d)
    {
        if(!d.nome.equals("")&& d.cod_emp!=0 &&!d.Descicao.equals("") && d.qtde_func!=0 && d.vagas!=0 )
        {
            dao.inserirDepartamento(d);
            JOptionPane.showMessageDialog(null,"Departamento realizado com sucesso");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }
    }
    
     public void modDepartamento(Departamento d)
    {
        if(!d.nome.equals("")&& d.cod_emp!=0 &&!d.Descicao.equals("") && d.qtde_func!=0 && d.vagas!=0 )
        {
            dao.modificarDepartamento(d);
            JOptionPane.showMessageDialog(null,"Alterações salvas com sucesso!!!");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }}
     
     public void delDep(int codigo)
    {
        int op = JOptionPane.showConfirmDialog(null, "Você tem certeza que quer excluir o departamento relacionado ao código "+codigo+"?","Certeza?",JOptionPane.YES_NO_OPTION);
       switch(op)
       {
           case 0 -> {
               dao.apagardep(codigo);
               JOptionPane.showMessageDialog(null, "Departamento eliminado com sucesso!!!");
            }
           case 1 -> JOptionPane.showMessageDialog(null, "Exclusão cancelada");
       }
       
    }
      public void countdep(Departamento d)
    {
        if(d.qtde_dep!=0 )
        {
            dao.countdep(d);
            JOptionPane.showMessageDialog(null,"Última contagem salva");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        }}
        
  public List<Departamento> updatedep(){
    
        lista.clear();
        lista = dao.getDepartamento();
        return lista;
    }
    
}
