
package model;

/**
 *
 * @author leoso
 */
public class Cadastro {
    public int id;
    public String CNPJ;
    public int IE;
    public int area_atuacao;
    public String nome;
    public String fantasia;
    public int qtde_dep;


    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
