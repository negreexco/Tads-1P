
package model;

/**
 *
 * @author leoso
 */
public class Usuario {
    public String Usuario;
    public String senha; 
}
