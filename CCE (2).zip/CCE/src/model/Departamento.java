
package model;

/**
 *
 * @author leoso
 */
public class Departamento {
    public String nome;
    public int qtde_func;
    public String Descicao;
    public int vagas;
    public int cod_emp;
    public int qtde_dep;
   
   
}
