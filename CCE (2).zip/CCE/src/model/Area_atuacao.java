
package model;


public class Area_atuacao {
    public int aid;
    public String area;
}
