
package model;

/**
 *
 * @author leoso
 */
public class Funcionario {
    public String nome;
    public String cpf;
    public String Cargo;
    public int cod_dep;
    public int salario;
    public int codigo;
}
