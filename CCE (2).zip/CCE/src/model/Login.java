
package model;

/**
 *
 * @author leoso
 */
public class Login {
    public String user;
    public String senha;


public void  Login (String u, String s){

  user = u;
  senha = s;
    }}