package daoccs;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import model.Area_atuacao;
import Connection.CceConnection;
import javax.swing.JOptionPane;

public class daoAA {
Connection con = null;
PreparedStatement pstm = null;

public List<Area_atuacao> getaa()
{
    List<Area_atuacao> lista = new ArrayList<Area_atuacao>();
    ResultSet rs = null;
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT * FROM Area",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    rs =  this.pstm.executeQuery();
    if(rs.first())
    {
        do{
            Area_atuacao aa = new Area_atuacao();
             aa.aid = rs.getInt("aid");
             aa.area=rs.getString("area");
             
             
             lista.add(aa);
            
        }while(rs.next());
    }
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de busca "+err);
        }
    }
    
    return lista;
}


public int idbyarea(String area)
{
    int id=0;
    ResultSet rs = null;
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT aid FROM Area WHERE area =?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setString(1, area);
    rs =  this.pstm.executeQuery();
    if(rs.first())
    {
       id = rs.getInt("aid");
    }
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de busca "+err);
        }
    }
    
    return id;
}


public String areabyid(String aid)
{
    String desc="";
    ResultSet rs = null;
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT area FROM Area WHERE aid =?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setString(1, aid);
    rs =  this.pstm.executeQuery();
    if(rs.first())
    {
       desc = rs.getString("area");
    }
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de busca "+err);
        }
    }
    
    return desc;
}




public List<String> carregaComboBox()
{
    List<String> lista = new ArrayList<String>();
    ResultSet rs = null;
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT area FROM Area ORDER BY area ASC",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    rs =  this.pstm.executeQuery();
    if(rs.first())
    {
        do{
            String aa =rs.getString("area");
             
             
             lista.add(aa);
            
        }while(rs.next());
    }
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de busca "+err);
        }
    }
    
    return lista;
}

public void saveaar(Area_atuacao aa)
{
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("INSERT INTO Area (area) VALUES (?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setString(1,aa.area );
    this.pstm.execute();
    
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao salvar area de mercado no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de salvamento "+err);
        }
    }
    

}

public void alteraa(Area_atuacao aa)
{
     con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("UPDATE Area SET area =? WHERE aid =?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setString(1,aa.area );
    pstm.setInt(2, aa.aid);
    this.pstm.execute();
    JOptionPane.showMessageDialog(null,"Area de mercado alterada com sucesso!!!");
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao alterar sua área de mercado no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de alteração "+err);
        }
    }
    

}





public void killaa(String aid)
{
 con = new CceConnection().getCceConnection();    
    try{
    pstm = con.prepareStatement("DELETE FROM Area WHERE aid=?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setString(1, aid);
    this.pstm.execute();
    JOptionPane.showMessageDialog(null,"A.A excluída com sucesso!!!");
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao excluir Area de trabalho no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de exclusão "+err);
        }
    }
    

}

}
