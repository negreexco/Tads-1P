
package daoccs;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import model.Cadastro;
import model.Departamento;
import Connection.CceConnection;
import javax.swing.JOptionPane;

public class DaoCadastro {
    
    /*parte do código que irá chamar os dados inseridos dentro do BD*/
     Connection con = null;
    PreparedStatement pstm = null;
    public List<Cadastro> getCadastro()
    {
    List<Cadastro> lista = new ArrayList<Cadastro>(); // Inicialize a lista antes de usá-la
    ResultSet rs = null;//armazena um milhão de dados mas só sabe o que é primeiro o último, anterior e próximo
    con = new CceConnection().getCceConnection();
    //se estiver certo, conectou
   try {
    pstm = con.prepareStatement("SELECT * FROM Cadastro",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    rs = this.pstm.executeQuery();
    if (rs.first()) {
        do {
            Cadastro c = new Cadastro();
            c.id = rs.getInt("Codigo");
            c.nome = rs.getString("Nome");
            c.CNPJ = rs.getString("CNPJ");
            c.IE = rs.getInt("Inscrição_estadual");
            c.area_atuacao = rs.getInt("Area_de_atuação");
            c.fantasia = rs.getString("fantasia");

            lista.add(c); 
     
    
    }while(rs.next());
    }
    pstm.close();
    }catch(SQLException erro)
    {
    JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
    con.close();
        }
        catch(SQLException err){
        
        JOptionPane.showMessageDialog(null, "erro ao fechar a conexão de busca");
        }
    }
    return lista;
    }
    

   public void inserirCadastro(Cadastro c) {
    con = new CceConnection().getCceConnection();
    try {
          pstm = con.prepareStatement( "INSERT INTO Cadastro (Nome, CNPJ, Inscrição_estadual, Area_de_atuação, fantasia ) VALUES (?, ?, ?, ?, ?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     
        pstm.setString(1, c.nome);
        pstm.setString(2, c.CNPJ);
        pstm.setInt(3, c.IE);
        pstm.setInt(4, c.area_atuacao);
        pstm.setString(5, c.fantasia);

        pstm.executeUpdate();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao inserir dados no BD " + erro);
    } finally {
        try {
            pstm.close();
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de inserção");
        }
    }
}
   public void modificarCadastro(Cadastro cce)
{
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("UPDATE Cadastro SET Nome=?, CNPJ=?, Inscrição_estadual=?, Area_de_atuação=?, fantasia=? WHERE Codigo=?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
   pstm.setString(1, cce.nome);
        pstm.setString(2, cce.CNPJ);
        pstm.setInt(3, cce.IE);
        pstm.setInt(4, cce.area_atuacao);
        pstm.setString(5, cce.fantasia);
        pstm.setInt(6,cce.id);
    this.pstm.execute();
    JOptionPane.showMessageDialog(null,"Cadastro modificado com sucesso!!!");
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao alterar seu cadastro no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de alteração "+err);
        }
    }
    

}
   
public void apagarCadastro(int codigo) {
    con = new CceConnection().getCceConnection();

    try {
        // Remove os registros em Departamento que estão relacionados ao Cadastro
        pstm = con.prepareStatement("DELETE FROM Departamento WHERE cod_emp=?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        pstm.setInt(1, codigo);
        pstm.executeUpdate();

        // Exclui o registro em Cadastro
        pstm = con.prepareStatement("DELETE FROM Cadastro WHERE Codigo=?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        pstm.setInt(1, codigo);
        int result = pstm.executeUpdate();

        // Verifica se algum registro foi excluído
        if (result > 0) {
            JOptionPane.showMessageDialog(null, "Cadastro excluído com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum cadastro encontrado para exclusão.");
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir cadastro no BD " + erro);
    } finally {
        try {
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de exclusão " + err);
        }
    }
}



public void procurar(Cadastro c) {
    con = new CceConnection().getCceConnection();
    
    try {
        pstm = con.prepareStatement("SELECT nome FROM Cadastro WHERE nome ILIKE ?");
        pstm.setString(1, "%" + c.nome + "%");

        ResultSet rs = this.pstm.executeQuery();

        // Exiba os resultados
        while (rs.next()) {
            String nomeEncontrado = rs.getString("nome");
            JOptionPane.showMessageDialog(null, "Resultado encontrado: " + nomeEncontrado);
        }

        rs.close();
        pstm.close();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD " + erro);
    } finally {
        try {
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de busca " + err);
        }
    }
}
public void inserirvagas(Cadastro c) {
    con = new CceConnection().getCceConnection();
    try {
          pstm = con.prepareStatement( "INSERT INTO Departamento (Nome, CNPJ, Inscrição_estadual, Area_de_atuação, fantasia, ) VALUES (?, ?, ?, ?, ?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     
        pstm.setString(1, c.nome);
        pstm.setString(2, c.CNPJ);
        pstm.setInt(3, c.IE);
        pstm.setInt(4, c.area_atuacao);
        pstm.setString(5, c.fantasia);

        pstm.executeUpdate();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao inserir dados no BD " + erro);
    } finally {
        try {
            pstm.close();
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de inserção");
        }
    }
}
}

 