
package daoccs;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import Connection.CceConnection;
import javax.swing.JOptionPane;
import model.Departamento;
/**
 *
 * @author leoso
 */
public class DaoDep {
        /*parte do código que irá chamar os dados inseridos dentro do BD*/
    Connection con = null;
    PreparedStatement pstm = null;
    public List<Departamento> getDepartamento()
    {
    List<Departamento> lista = new ArrayList<Departamento>(); // Inicialize a lista antes de usá-la
    ResultSet rs = null;//armazena um milhão de dados mas só sabe o que é primeiro o último, anterior e próximo
    con = new CceConnection().getCceConnection();
    //se estiver certo, conectou
   try {
    pstm = con.prepareStatement("SELECT * FROM Departamento",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    rs = this.pstm.executeQuery();
    if (rs.first()) {
        do {
            Departamento d = new Departamento();
            d.nome = rs.getString("Nome");
            d.Descicao = rs.getString("descricao");
            d.qtde_func = rs.getInt("qtde_funcionarios");
            d.vagas = rs.getInt("vagas");
            d.cod_emp = rs.getInt("cod_emp");

            lista.add(d); 
     
    
    }while(rs.next());
    }
    pstm.close();
    }catch(SQLException erro)
    {
    JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
    con.close();
        }
        catch(SQLException err){
        
        JOptionPane.showMessageDialog(null, "erro ao fechar a conexão de busca");
        }
    }
    return lista;
    }
     public void inserirDepartamento(Departamento d) {
    con = new CceConnection().getCceConnection();
    try {
          pstm = con.prepareStatement( "INSERT INTO Departamento (nome, Descricao, qtde_funcionarios, vagas, cod_emp ) VALUES (?, ?, ?, ?, ?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     
        pstm.setString(1, d.nome);
        pstm.setString(2, d.Descicao);
        pstm.setInt(3, d.qtde_func);
        pstm.setInt(4, d.vagas);
        pstm.setInt(5, d.cod_emp);

        pstm.executeUpdate();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao inserir dados no BD " + erro);
    } finally {
        try {
            pstm.close();
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de inserção");
        }
    }
}
   public void modificarDepartamento(Departamento dep)
{
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("UPDATE Departamento SET (nome, Descricao, qtde_funcionarios, vagas,) VALUES (?,?,?,?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
   pstm.setString(1, dep.nome);
        pstm.setString(2, dep.Descicao);
        pstm.setInt(3, dep.qtde_func);
        pstm.setInt(3, dep.vagas);
      
    this.pstm.execute();
    JOptionPane.showMessageDialog(null,"Departamento modificado com sucesso!!!");
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao alterar seu cadastro no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de alteração "+err);
        }
    }
}
    public void countdep(Departamento dep){
     con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT COUNT (*) from Departamento where cod_emp=?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setInt(1,dep.qtde_dep);
      
    this.pstm.execute();    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar quantidade de departamentos no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de contagem  "+err);
        }
    }
    
    }
    public void apagardep(int codigo) {
    con = new CceConnection().getCceConnection();

    try {
        // Remove os registros em Departamento que estão relacionados ao Cadastro
        pstm = con.prepareStatement("DELETE FROM Departamento WHERE Codigo_dep=?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        pstm.setInt(1, codigo);
        pstm.executeUpdate();


    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir departamento no BD " + erro);
    } finally {
        try {
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de exclusão " + err);
        }
    }
}
    
}
