
package daoccs;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import Connection.CceConnection;
import javax.swing.JOptionPane;
import model.Funcionario;
/**
 *
 * @author leoso
 */
public class DaoFunc {
    Connection con = null;
    PreparedStatement pstm = null;
    public List<Funcionario> getFuncionario()
     {
    List<Funcionario> lista = new ArrayList<Funcionario>(); // Inicialize a lista antes de usá-la
    ResultSet rs = null;//armazena um milhão de dados mas só sabe o que é primeiro o último, anterior e próximo
    con = new CceConnection().getCceConnection();
    //se estiver certo, conectou
   try {
    pstm = con.prepareStatement("SELECT * FROM Funcionario",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    rs = this.pstm.executeQuery();
    if (rs.first()) {
        do {
            Funcionario f = new Funcionario();
            f.nome = rs.getString("Nome");
            f.Cargo = rs.getString("Cargo");
            f.cpf = rs.getString("cpf");
            f.cod_dep = rs.getInt("cod_dep");
            f.codigo = rs.getInt("codigo");
            f.salario = rs.getInt("salario");
            

            lista.add(f); 
     
    
    }while(rs.next());
    }
    pstm.close();
    }catch(SQLException erro)
    {
    JOptionPane.showMessageDialog(null, "Erro ao buscar dados no BD "+erro);
    }
    finally{
        try{
    con.close();
        }
        catch(SQLException err){
        
        JOptionPane.showMessageDialog(null, "erro ao fechar a conexão de busca");
        }
    }
    return lista;
     }
    public void Contratar(Funcionario f) {
    con = new CceConnection().getCceConnection();
    try {
          pstm = con.prepareStatement( "INSERT INTO Funcionario (Nome, Cargo, cpf, cod_dep, salario ) VALUES (?, ?, ?, ?, ?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     
        pstm.setString(1, f.nome);
        pstm.setString(2, f.Cargo);
        pstm.setString(3, f.cpf);
        pstm.setInt(4, f.cod_dep);
        pstm.setInt(5, f.salario);

        pstm.executeUpdate();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao inserir dados no BD " + erro);
    } finally {
        try {
            pstm.close();
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de inserção");
        }
    }
}
   public void Remanejar(Funcionario f)
{
    con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("UPDATE Cadastro SET Nome=?, Cargo=?, cpf=?, cod_dep=?, salario=? WHERE codigo =?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
        pstm.setString(1, f.nome);
        pstm.setString(2, f.Cargo);
        pstm.setString(3, f.cpf);
        pstm.setInt(4,f.cod_dep );
        pstm.setInt(5, f.salario);
        pstm.setInt(6, f.codigo);
        
        
      
    this.pstm.execute();
    JOptionPane.showMessageDialog(null,"Departamento modificado com sucesso!!!");
    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao alterar seu cadastro no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de alteração "+err);
        }
    }
}
    public void countdep(Funcionario f){
     con = new CceConnection().getCceConnection();
    
    try{
    pstm = con.prepareStatement("SELECT COUNT (*) from Funcionario where cod_dep=?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    pstm.setInt(1,f.cod_dep);
      
    this.pstm.execute();    
    pstm.close();
    }
    catch(SQLException erro)
    {
        JOptionPane.showMessageDialog(null, "Erro ao buscar quantidade de departamentos no BD "+erro);
    }
    finally{
        try{
        con.close();
        }
        catch(SQLException err)
        {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de contagem  "+err);
        }
    }
    
    }
    public void Demitir(int codigo) {
    con = new CceConnection().getCceConnection();

    try {
        // Remove os registros em Departamento que estão relacionados ao Cadastro
        pstm = con.prepareStatement("DELETE FROM Funcionario WHERE codigo=?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        pstm.setInt(1, codigo);
        pstm.executeUpdate();


    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir departamento no BD " + erro);
    } finally {
        try {
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de exclusão " + err);
        }
    }
}
     
}
