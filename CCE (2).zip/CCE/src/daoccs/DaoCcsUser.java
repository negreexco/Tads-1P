
package daoccs;

import Connection.CceConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Usuario;

/**
 *
 * @author leoso
 */
public class DaoCcsUser {
    Connection con = null;
    PreparedStatement pstm = null;

    private Connection obterConexao() {
        return new CceConnection().getCceConnection();
    }

    private void fecharConexao() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão: " + e.getMessage());
        }
    }

    private void tratarErroSQLException(SQLException e, String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem + e.getMessage());
    }

    public List<Usuario> getUsuarios() {
        List<Usuario> lista = new ArrayList<Usuario>();
        ResultSet rs = null;

        con = obterConexao();
        JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso ao buscar");

        try {
            pstm = con.prepareStatement("SELECT * FROM CceUser",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs = this.pstm.executeQuery();
            
            while (rs.next()) {
                Usuario u = new Usuario();
                u.Usuario =(rs.getString("Usuario"));
                u.senha = (rs.getString("senha"));
                lista.add(u);
            }
        } catch (SQLException erro) {
            tratarErroSQLException(erro, "Erro ao procurar dados no BD ");
        } finally {
            fecharConexao();
        }

        return lista;
    }

    public boolean validarlogin(String user, String senha) {
        boolean resp = false;
        ResultSet rs = null;

        con = obterConexao();

        try {
            pstm = con.prepareStatement("SELECT * FROM CceUser WHERE Usuario=? and senha=?",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
            pstm.setString(1, user);
            pstm.setString(2, senha);
            rs = this.pstm.executeQuery();

            if (rs.first()) {
                resp = true;
            }
        } catch (SQLException erro) {
            tratarErroSQLException(erro, "Erro ao procurar dados no BD ");
        } finally {
            fecharConexao();
        }

        return resp;
    }
     public void inserirCadastro(Usuario u) {
    con = new CceConnection().getCceConnection();
    try {
          pstm = con.prepareStatement( "INSERT INTO CceUser (Usuario, senha ) VALUES (?, ?)",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     
        pstm.setString(1, u.Usuario);
        pstm.setString(2, u.senha);
       

        pstm.executeUpdate();
    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(null, "Erro ao inserir cadastro no BD " + erro);
    } finally {
        try {
            pstm.close();
            con.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão de cadastro");
        }
    }
}
}


