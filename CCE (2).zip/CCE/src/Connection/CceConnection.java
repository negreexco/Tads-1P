
package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CceConnection {
    
   public void coneccao(){

     String url = "jdbc:postgresql://localhost:5433/postgres";
     String user = "postgres";
     String password = "848660";
     try{
        Connection con = DriverManager.getConnection(url, user, password);
        JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso");
        con.close();
} catch(SQLException e){
    JOptionPane.showMessageDialog(null, "fonte do banco de dados não encontrada: " +e.getMessage());

}
    }

    public Connection getCceConnection() {
        try {
          
            String url = "jdbc:postgresql://localhost:5433/CCE cadastro";
            String usuario = "postgres";
            String senha = "848660";

            Connection coneccao = DriverManager.getConnection(url, usuario, senha);
            return coneccao;
        } catch (SQLException e) {
           
            throw new RuntimeException("Erro ao obter conexão com o banco de dados", e);
        }
    }
}
