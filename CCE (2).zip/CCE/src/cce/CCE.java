
package cce;
import view.CceLogin;
import Connection.CceConnection;
/**
 *
 * @author leoso
 */
public class CCE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      CceConnection c = new CceConnection();
      c.coneccao();
      CceLogin log = new CceLogin();
      log.setVisible(true);
      
      
    }
    
}
