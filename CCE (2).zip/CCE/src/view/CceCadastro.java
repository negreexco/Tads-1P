
package view;
import controller.ControllerAA;
import controller.ControllerCadastro;
import controller.ControllerDep;
import java.util.List;
import model.Cadastro;
import model.Departamento;
import javax.swing.JOptionPane;


/**
 *
 * @author leoso
 */
public class CceCadastro extends javax.swing.JInternalFrame {
   int indice = 0;
    ControllerAA controlaa = new ControllerAA(); 
    ControllerCadastro controlc =  new ControllerCadastro();
    ControllerDep d = new ControllerDep();
    
   List<Cadastro> clist = controlc.upupCadastro();
   List<Departamento> dlist = d.updatedep();
   List<String> cmbaa = controlaa.cmbopen();
   
    public CceCadastro() {
      
        initComponents();
        cdsid.setEnabled(false);
      
        /*  cdsnome.setEnabled(true);
        cdscnpj.setEnabled(true);
        cdsie.setEnabled(true);
        cdsarea.setEnabled(true);
        cdsfantasia.setEnabled(true);*/
  
        while(!cmbaa.isEmpty())
        {
            cdsarea.addItem(cmbaa.get(0));
            cmbaa.remove(0);
        }
        
        
        if(clist.isEmpty())
        {
            cdscnpj.setEnabled(false);
            cdsnome.setEnabled(false);
            cdsie.setEnabled(false);
            cdsfantasia.setEnabled(false);
        }
        else
        {
            indice=0;
            mostrarCadastro();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dep = new javax.swing.JPanel();
        cdssave = new javax.swing.JButton();
        cdsdel = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cdsnome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cdscnpj = new java.awt.TextField();
        jLabel2 = new javax.swing.JLabel();
        cdsie = new javax.swing.JTextField();
        cdsfantasia = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cdsarea = new javax.swing.JComboBox<>();
        cdsnew = new javax.swing.JButton();
        cdsfirst = new java.awt.Button();
        cdsanterior = new java.awt.Button();
        cdsprox = new java.awt.Button();
        cdslast = new java.awt.Button();
        button1 = new java.awt.Button();
        cdslupa = new java.awt.TextField();
        jLabel6 = new javax.swing.JLabel();
        cdsid = new javax.swing.JTextField();
        cdsedit = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastrar empresas");
        setFont(new java.awt.Font("Candara", 0, 10)); // NOI18N
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cdssave.setText("📁");
        cdssave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cdssaveMouseEntered(evt);
            }
        });
        cdssave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdssaveActionPerformed(evt);
            }
        });

        cdsdel.setText("🚮");
        cdsdel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cdsdelMouseEntered(evt);
            }
        });
        cdsdel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsdelActionPerformed(evt);
            }
        });

        jLabel4.setText("Nome");

        cdsnome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cdsnomeMouseEntered(evt);
            }
        });
        cdsnome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsnomeActionPerformed(evt);
            }
        });

        jLabel1.setText("CNPJ");

        cdscnpj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdscnpjActionPerformed(evt);
            }
        });

        jLabel2.setText("Inscrição Estadual");

        cdsie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsieActionPerformed(evt);
            }
        });

        cdsfantasia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsfantasiaActionPerformed(evt);
            }
        });

        jLabel5.setText("Fantasia");

        jLabel3.setText("Área de atuação");

        cdsarea.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Selecionar --" }));
        cdsarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsareaActionPerformed(evt);
            }
        });

        cdsnew.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdsnew.setText("NEW");
        cdsnew.setToolTipText("");
        cdsnew.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cdsnewMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cdsnewMouseEntered(evt);
            }
        });
        cdsnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsnewActionPerformed(evt);
            }
        });

        cdsfirst.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdsfirst.setLabel("Primeiro registro");
        cdsfirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsfirstActionPerformed(evt);
            }
        });

        cdsanterior.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdsanterior.setLabel("|<<");
        cdsanterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsanteriorActionPerformed(evt);
            }
        });

        cdsprox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdsprox.setLabel(">>|");
        cdsprox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdsproxActionPerformed(evt);
            }
        });

        cdslast.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdslast.setLabel("Ultimo Registro");
        cdslast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdslastActionPerformed(evt);
            }
        });

        button1.setLabel("OK");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        cdslupa.setText("procurar");
        cdslupa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cdslupaMouseClicked(evt);
            }
        });
        cdslupa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdslupaActionPerformed(evt);
            }
        });

        jLabel6.setText("Código");

        cdsedit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cdsedit.setText("EDITAR");
        cdsedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdseditActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout depLayout = new javax.swing.GroupLayout(dep);
        dep.setLayout(depLayout);
        depLayout.setHorizontalGroup(
            depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, depLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(depLayout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(cdsfirst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(cdsanterior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(cdsprox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(cdslast, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(depLayout.createSequentialGroup()
                        .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(depLayout.createSequentialGroup()
                                .addComponent(cdsfantasia, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cdsarea, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(depLayout.createSequentialGroup()
                                .addComponent(cdscnpj, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cdsie, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cdsnome, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(depLayout.createSequentialGroup()
                        .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(depLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(cdsid, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(157, 157, 157)
                                .addComponent(cdssave, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cdsdel, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cdslupa, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(depLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(cdsnew)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cdsedit)))
                .addGap(17, 17, 17))
        );
        depLayout.setVerticalGroup(
            depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(depLayout.createSequentialGroup()
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(depLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))
                    .addGroup(depLayout.createSequentialGroup()
                        .addComponent(cdslupa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(depLayout.createSequentialGroup()
                                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cdsdel)
                                    .addComponent(cdssave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE))
                            .addGroup(depLayout.createSequentialGroup()
                                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(cdsid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cdsnome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(cdscnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(cdsie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17)
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cdsfantasia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(cdsarea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cdsnew)
                    .addComponent(cdsedit))
                .addGap(42, 42, 42)
                .addGroup(depLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cdsfirst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cdsanterior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cdsprox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cdslast, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(dep, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cdsieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cdsieActionPerformed

    private void cdsareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsareaActionPerformed
        String area = cdsarea.getSelectedItem().toString();
    }//GEN-LAST:event_cdsareaActionPerformed

    private void cdssaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdssaveActionPerformed
     Cadastro emp = new Cadastro();
        
        emp.nome = cdsnome.getText();
        emp.CNPJ = cdscnpj.getText();
        emp.IE =  Integer.parseInt(  cdsie.getText());
        emp.area_atuacao = controlaa.idbyarea(cdsarea.getSelectedItem().toString());
        emp.fantasia = cdsfantasia.getText();
       
        
        
        controlc.inserirCadastro(emp);
       
       
        clist = controlc.upupCadastro();
        indice= clist.size()-1;
        mostrarCadastro();   
        cdsfirst.setEnabled(true);

    }//GEN-LAST:event_cdssaveActionPerformed

    private void cdsfirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsfirstActionPerformed
        indice =0;
        mostrarCadastro();
    }//GEN-LAST:event_cdsfirstActionPerformed

    private void cdslastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdslastActionPerformed
     indice = clist.size()-1;
       mostrarCadastro();
    }//GEN-LAST:event_cdslastActionPerformed

    private void cdsanteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsanteriorActionPerformed
        if(indice>0)
        {
          indice--;
          mostrarCadastro();
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Você já está no primeiro item","Atenção",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_cdsanteriorActionPerformed

    private void cdsproxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsproxActionPerformed
        if(indice<clist.size()-1){
          indice++;
          mostrarCadastro();
        }else
        {
            JOptionPane.showMessageDialog(this, "Você já está no último item","Atenção",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_cdsproxActionPerformed

    private void cdsfantasiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsfantasiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cdsfantasiaActionPerformed

    private void cdsdelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsdelActionPerformed
        d.delDep(Integer.parseInt(cdsid.getText()));
        dlist = d.updatedep();
        indice= dlist.size()-1;
        
        controlc.trashCce(Integer.parseInt(cdsid.getText()));
        clist = controlc.upupCadastro();
        indice= clist.size()-1;
              
        mostrarCadastro();     
    }//GEN-LAST:event_cdsdelActionPerformed

    private void cdsnomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsnomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cdsnomeActionPerformed

    private void cdscnpjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdscnpjActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cdscnpjActionPerformed

    private void cdssaveMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdssaveMouseEntered
      
    }//GEN-LAST:event_cdssaveMouseEntered

    private void cdsdelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdsdelMouseEntered

    }//GEN-LAST:event_cdsdelMouseEntered

    private void cdsnewMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdsnewMouseEntered
     
    }//GEN-LAST:event_cdsnewMouseEntered

    private void cdsnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdsnewActionPerformed
              
      cdsnome.setText("");
      cdscnpj.setText("");
      cdsie.setText("");
      cdsfantasia.setText("");
      cdsarea.setSelectedItem("--Selecionar--");   
       
      cdsnome.setEnabled(true);
      cdscnpj.setEnabled(true);
      cdsie.setEnabled(true);
      cdsfantasia.setEnabled(true);
      
    }//GEN-LAST:event_cdsnewActionPerformed

    private void cdsnomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdsnomeMouseEntered
      
    }//GEN-LAST:event_cdsnomeMouseEntered

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_formFocusGained

    private void cdslupaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdslupaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cdslupaActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
    Cadastro emp = new Cadastro();
    emp.nome = cdslupa.getText();

    controlc.procurar(emp);

    clist = controlc.upupCadastro();
    if (!clist.isEmpty()) {
        indice = clist.size()-1;
    }
    mostrarCadastro();
    }//GEN-LAST:event_button1ActionPerformed

    private void cdslupaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdslupaMouseClicked
       cdslupa.setText("");
    }//GEN-LAST:event_cdslupaMouseClicked

    private void cdsnewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdsnewMouseClicked
      CceCadastro c = new CceCadastro();
        
      c.cdsnome.setText("");
      c.cdscnpj.setText("");
      c.cdsie.setText("");
      c.cdsfantasia.setText("");
      c.cdsarea.setSelectedItem("--Selecionar--");  
      
      cdsnome.setEnabled(true);
      cdscnpj.setEnabled(true);
      cdsie.setEnabled(true);
      cdsfantasia.setEnabled(true);
    }//GEN-LAST:event_cdsnewMouseClicked

    private void cdseditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdseditActionPerformed
        Cadastro c = new Cadastro();
        
        c.id= Integer.parseInt(cdsid.getText());
        c.nome = cdsnome.getText();
        c.CNPJ = cdscnpj.getText();
        c.IE =  Integer.parseInt(  cdsie.getText());
        c.area_atuacao = controlaa.idbyarea(cdsarea.getSelectedItem().toString());
        c.fantasia = cdsfantasia.getText();
       
        
        controlc.modCadastro(c);
       
        clist = controlc.upupCadastro();
        indice= clist.size()-1;
        mostrarCadastro();
        
      
    }//GEN-LAST:event_cdseditActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button cdsanterior;
    public javax.swing.JComboBox<String> cdsarea;
    public java.awt.TextField cdscnpj;
    private javax.swing.JButton cdsdel;
    private javax.swing.JButton cdsedit;
    public javax.swing.JTextField cdsfantasia;
    private java.awt.Button cdsfirst;
    private javax.swing.JTextField cdsid;
    public javax.swing.JTextField cdsie;
    private java.awt.Button cdslast;
    private java.awt.TextField cdslupa;
    private javax.swing.JButton cdsnew;
    public javax.swing.JTextField cdsnome;
    private java.awt.Button cdsprox;
    private javax.swing.JButton cdssave;
    private javax.swing.JPanel dep;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
public void mostrarCadastro(){
       cdsid.setText(""+clist.get(indice).id);
       cdsnome.setText(""+clist.get(indice).nome);
       cdscnpj.setText(""+clist.get(indice).CNPJ);
       cdsie.setText(""+clist.get(indice).IE);
       cdsarea.setSelectedItem(""+clist.get(indice).area_atuacao);
       cdsfantasia.setText(clist.get(indice).fantasia+"");
       
}

}
